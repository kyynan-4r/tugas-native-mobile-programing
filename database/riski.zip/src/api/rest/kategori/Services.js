const { db } = require('../../../utils/database');

const dbModel = db.kategori;

module.exports = {
  dbModel,
};
