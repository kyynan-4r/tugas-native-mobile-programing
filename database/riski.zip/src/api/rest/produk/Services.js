const { db } = require('../../../utils/database');

const dbModel = db.produk;

module.exports = {
  dbModel,
};
