const { db } = require('../../../utils/database');

const dbModel = db.pengguna;

module.exports = {
  dbModel,
};
