const { db } = require('../../../utils/database');

const dbModel = db.pemasok;

module.exports = {
  dbModel,
};
