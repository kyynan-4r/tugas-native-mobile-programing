const express = require('express');

const router = express.Router();

// Users Model
router.use('/pengguna', require('./pengguna/Routes'));
router.use('/produk', require('./produk/Routes'));
router.use('/kategori', require('./kategori/Routes'));
router.use('/pemasok', require('./pemasok/Routes'));

module.exports = router;
