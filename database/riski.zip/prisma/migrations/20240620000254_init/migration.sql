/*
  Warnings:

  - You are about to drop the column `Role` on the `Pengguna` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Pengguna" DROP COLUMN "Role",
ADD COLUMN     "role" "ROLE" NOT NULL DEFAULT 'admin';
